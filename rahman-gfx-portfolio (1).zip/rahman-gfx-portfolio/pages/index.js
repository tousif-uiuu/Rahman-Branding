import { Instagram, Facebook } from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800">Rahman_GFX</h1>
        <p className="text-lg text-gray-600 mt-2">
          Professional Graphic Designer with 7 Years of Experience
        </p>
        <div className="flex justify-center gap-4 mt-4">
          <a href="https://www.instagram.com/YOUR_INSTA" target="_blank" rel="noopener noreferrer">
            <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-gray-200">
              <Instagram className="w-5 h-5" />
              Instagram
            </button>
          </a>
          <a href="https://www.facebook.com/YOUR_FB" target="_blank" rel="noopener noreferrer">
            <button className="flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-gray-200">
              <Facebook className="w-5 h-5" />
              Facebook
            </button>
          </a>
        </div>
      </header>

      <section>
        <h2 className="text-2xl font-semibold text-gray-800 mb-6">Portfolio</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((item) => (
            <div key={item} className="bg-white p-4 rounded-lg shadow hover:shadow-lg transition-shadow">
              <img
                src={`https://via.placeholder.com/300x200?text=Project+${item}`}
                alt={`Project ${item}`}
                className="rounded-lg mb-4"
              />
              <h3 className="text-lg font-medium">Project {item}</h3>
              <p className="text-sm text-gray-600">Short description of the project goes here.</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}